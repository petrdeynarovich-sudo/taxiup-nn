
  # Продвижение услуг ремонта

  This is a code bundle for Продвижение услуг ремонта. The original project is available at https://www.figma.com/design/fylrsafCVD8bAoaGhZxHfG/%D0%9F%D1%80%D0%BE%D0%B4%D0%B2%D0%B8%D0%B6%D0%B5%D0%BD%D0%B8%D0%B5-%D1%83%D1%81%D0%BB%D1%83%D0%B3-%D1%80%D0%B5%D0%BC%D0%BE%D0%BD%D1%82%D0%B0.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  